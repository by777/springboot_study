# P14 静态资源配置

以maven的形式引入jQuery。

```xml

<dependency>
    <groupId>org.webjars</groupId>
    <artifactId>jquery</artifactId>
    <version>3.4.1</version>
</dependency>
```

可以查看是否添加成功，在webjars找到所有的东西，都符合这个结构：
![img.png](imgs/img.png)

+ classpath:/META-INF/resources
+ classpath:/resources/（优先级1）
+ classpath:/static/（优先级2）
+ classpath:/public/（优先级3）

可以尝试在resources/public新建，1.js（输入hello），浏览器访问localhost:8080/1.js静态资源
template目录下只有在controller中才可以跳转到，相当于WEB-INF

# P15 首页和图标定制

