package com.bai.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/*
 * @Controller：标识一个Spring类是Spring MVC controller处理器,
 * @RestController：@RestController是@Controller和@ResponseBody的结合体，两个标注合并起来的作用。
 * @Controller类中的方法可以直接通过返回String跳转到jsp、ftl、html等模版页面。
 * 在方法上加@ResponseBody注解，也可以返回实体对象。
 * @RestController类中的所有方法只能返回String、Object、Json等实体对象，不能跳转到模版页面。*/
@RestController // RestController不用跳试图了
public class HelloController {
    @GetMapping("/hello")
    public String hello() {
        return "hello, world!";
    }
}
