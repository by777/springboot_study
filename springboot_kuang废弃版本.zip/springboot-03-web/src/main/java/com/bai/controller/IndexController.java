package com.bai.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // 这个Controller代表会跳到一个页面
public class IndexController {
    @RequestMapping("/index")
    public String index() {
        return "index";
    }
}
