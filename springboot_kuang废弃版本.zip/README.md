# Spring Boot学习

spring boot是spring cloud的基础

视频地址
https://www.bilibili.com/video/BV1PE411i7CV?p=4

# 工程创建

步骤在imgs文件夹中，主要修改网址和勾选web依赖

# 运行

HelloworldApplication运行后可以打开本机8080端口查看页面,
改变代码要重启服务。因此可以设置热启动

```xml
```

# 打包

打开maven工具栏，helloworld中找到package，双击。
成功后target文件夹中有成功的jar包。
helloworld-0.0.1-SNAPSHOT.jar
cmd执行

```cmd
java -jar helloworld-0.0.1-SNAPSHOT.jar
```




